[First image set]
- Mesona1.JPG
- Mesona2.JPG
* intrinsic matrices for both images are the same.
--------------------
[Second image set]
- Statue1.bmp (captured by camera A)
- Statue2.bmp (captured by camera B)
- Statue_calib.txt (provides calibration parameters for camera A and B)
* please note that the extrinsic matrices (rotation and translation) are only for your reference,
you should still estimate the fundamental matrix, essential matrix, and 3D points on your own.
--------------------
[Functions]
- obj_main.m helps you to do texture mapping and create 3D model 
